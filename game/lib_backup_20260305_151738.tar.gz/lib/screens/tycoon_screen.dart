import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mg_common_game/core/ui/theme/app_colors.dart';
import 'package:mg_common_game/core/ui/theme/app_text_styles.dart';

import '../features/materials/material_inventory.dart';
import '../features/materials/material_data.dart';
import '../features/economy/economy_manager.dart';
import '../features/crafting/crafting_manager.dart';
import '../features/crafting/recipe_data.dart';
import '../features/crafting/recipe_unlock.dart';
import '../features/shop/shop_manager.dart';
import '../features/stations/station_manager.dart';
import '../features/save/save_manager.dart';
import '../features/dungeon/dungeon_manager.dart';
import '../features/upgrades/upgrade_manager.dart';
import '../features/achievements/achievement_manager.dart';
import '../features/achievements/achievement_data.dart';
import '../features/decoration/decoration_manager.dart';
import '../features/decoration/decoration_data.dart';

class TycoonScreen extends StatefulWidget {
  const TycoonScreen({super.key});

  @override
  State<TycoonScreen> createState() => _TycoonScreenState();
}

class _TycoonScreenState extends State<TycoonScreen>
    with TickerProviderStateMixin {
  int _selectedTab = 0;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _selectedTab = _tabController.index;
      });
    });

    // Start game loop for idle production
    _startGameLoop();
  }

  void _startGameLoop() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        final inventory = context.read<MaterialInventory>();
        final crafting = context.read<CraftingManager>();
        final shop = context.read<ShopManager>();
        final dungeon = context.read<DungeonManager>();

        inventory.updateProduction(1.0); // 1 second
        crafting.update();
        shop.update();
        dungeon.update();

        _startGameLoop();
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dungeon Craft Tycoon'),
        backgroundColor: AppColors.primary,
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            tooltip: '저장',
            onPressed: () {
              final saveManager = context.read<SaveManager>();
              saveManager.saveGame().then((success) {
                if (success && mounted) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(const SnackBar(content: Text('게임 저장 완료!')));
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.folder_open),
            tooltip: '불러오기',
            onPressed: () {
              final saveManager = context.read<SaveManager>();
              saveManager.loadGame().then((success) {
                if (success && mounted) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(const SnackBar(content: Text('게임 불러오기 완료!')));
                } else if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('저장된 게임이 없습니다.')),
                  );
                }
              });
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: const [
            Tab(icon: Icon(Icons.inventory), text: '재료'),
            Tab(icon: Icon(Icons.build), text: '제작'),
            Tab(icon: Icon(Icons.store), text: '상점'),
            Tab(icon: Icon(Icons.upgrade), text: '업그레이드'),
            Tab(icon: Icon(Icons.explore), text: '던전'),
            Tab(icon: Icon(Icons.emoji_events), text: '업적'),
          ],
        ),
      ),
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          _buildCurrencyBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildMaterialsTab(),
                _buildCraftingTab(),
                _buildShopTab(),
                _buildUpgradeTab(),
                _buildDungeonTab(),
                _buildAchievementsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrencyBar() {
    return Consumer<EconomyManager>(
      builder: (context, economy, child) {
        return Container(
          padding: const EdgeInsets.all(16),
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.panel,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primary),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildCurrencyItem(
                Icons.monetization_on,
                '골드',
                economy.gold,
                Colors.yellow,
              ),
              _buildCurrencyItem(
                Icons.diamond,
                '보석',
                economy.gems,
                Colors.cyan,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCurrencyItem(
    IconData icon,
    String label,
    int amount,
    Color color,
  ) {
    return Row(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label, style: AppTextStyles.caption),
            Text(
              '$amount',
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMaterialsTab() {
    return Consumer<MaterialInventory>(
      builder: (context, inventory, child) {
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: MaterialType.values.length,
          itemBuilder: (context, index) {
            final type = MaterialType.values[index];
            final data = MaterialData.getByType(type);
            final amount = inventory.getMaterial(type);
            final rate = inventory.productionRates[type] ?? 0.0;

            return Card(
              color: AppColors.panel,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: _getMaterialColor(type).withOpacity(0.3),
                  child: Icon(
                    _getMaterialIcon(type),
                    color: _getMaterialColor(type),
                  ),
                ),
                title: Text(data.name, style: AppTextStyles.body),
                subtitle: Text(
                  '${data.description}\n생산: ${rate.toStringAsFixed(1)}/초',
                  style: AppTextStyles.caption,
                ),
                trailing: Text(
                  amount.toInt().toString(),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                isThreeLine: true,
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildCraftingTab() {
    return Consumer2<CraftingManager, MaterialInventory>(
      builder: (context, crafting, inventory, child) {
        final recipes = crafting.getUnlockedRecipes();

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: CraftingStation.values.length,
          itemBuilder: (context, index) {
            final station = CraftingStation.values[index];
            final job = crafting.getJobForStation(station);
            final stationRecipes = recipes
                .where((r) => r.station == station)
                .toList();

            return _buildStationCard(
              station,
              job,
              stationRecipes,
              crafting,
              inventory,
            );
          },
        );
      },
    );
  }

  Widget _buildStationCard(
    CraftingStation station,
    CraftingJob? job,
    List<Recipe> recipes,
    CraftingManager crafting,
    MaterialInventory inventory,
  ) {
    return Card(
      color: AppColors.panel,
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(_getStationIcon(station), color: AppColors.primary),
                const SizedBox(width: 8),
                Text(_getStationName(station), style: AppTextStyles.header2),
              ],
            ),
            const SizedBox(height: 12),

            // Active job or select recipe
            if (job != null && !job.isComplete) ...[
              Text('제작 중: ${job.recipe.name}', style: AppTextStyles.body),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: job.progress),
              const SizedBox(height: 4),
              Text(
                '남은 시간: ${job.remainingTime.inSeconds}초',
                style: AppTextStyles.caption,
              ),
            ] else if (job != null && job.isComplete) ...[
              Text(
                '완료: ${job.recipe.name}',
                style: const TextStyle(color: Colors.green),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: () {
                  final item = crafting.completeCrafting(station);
                  if (item != null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          '${item.name} (${_getQualityName(item.quality)}) 제작 완료!',
                        ),
                      ),
                    );
                  }
                },
                child: const Text('수령하기'),
              ),
            ] else ...[
              DropdownButton<Recipe>(
                isExpanded: true,
                hint: const Text('레시피 선택...'),
                items: recipes.map((recipe) {
                  final canCraft = crafting.canStartCrafting(recipe);
                  return DropdownMenuItem(
                    value: recipe,
                    child: Text(
                      '${recipe.name} (${recipe.craftingTime}초)',
                      style: TextStyle(
                        color: canCraft ? Colors.white : Colors.grey,
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (recipe) {
                  if (recipe != null && crafting.startCrafting(recipe)) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${recipe.name} 제작 시작!')),
                    );
                  }
                },
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildShopTab() {
    return Consumer3<ShopManager, CraftingManager, EconomyManager>(
      builder: (context, shop, crafting, economy, child) {
        return Column(
          children: [
            // Customer info
            if (shop.currentCustomer != null) ...[
              Container(
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green),
                ),
                child: Column(
                  children: [
                    Text(
                      '고객: ${shop.currentCustomer!.name}',
                      style: AppTextStyles.header2,
                    ),
                    Text(
                      '예산: ${shop.currentCustomer!.budget.toInt()} 골드',
                      style: AppTextStyles.body,
                    ),
                    Text(
                      '남은 시간: ${shop.customerTimeRemaining.inSeconds}초',
                      style: AppTextStyles.caption,
                    ),
                  ],
                ),
              ),
            ],

            // Display slots
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.8,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: shop.maxDisplaySlots,
                itemBuilder: (context, index) {
                  if (index < shop.displayedItems.length) {
                    final item = shop.displayedItems[index];
                    final interested =
                        shop.currentCustomer?.isInterested(item) ?? false;

                    return _buildDisplaySlot(item, interested, shop, economy);
                  } else {
                    return _buildEmptySlot(crafting, shop);
                  }
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDisplaySlot(
    CraftedItem item,
    bool interested,
    ShopManager shop,
    EconomyManager economy,
  ) {
    return Card(
      color: interested ? Colors.green.withOpacity(0.2) : AppColors.panel,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              item.name,
              style: AppTextStyles.body,
              textAlign: TextAlign.center,
            ),
            Text(
              _getQualityName(item.quality),
              style: TextStyle(color: _getQualityColor(item.quality)),
            ),
            Text(
              '${item.sellPrice} 골드',
              style: const TextStyle(color: Colors.yellow),
            ),
            if (interested)
              ElevatedButton(
                onPressed: () {
                  final price = shop.sellItem(item);
                  if (price != null) {
                    economy.addGold(price);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${item.name} 판매! +$price 골드')),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('판매'),
              )
            else
              TextButton(
                onPressed: () => shop.removeFromDisplay(item),
                child: const Text('회수'),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptySlot(CraftingManager crafting, ShopManager shop) {
    final items = crafting.completedItems;

    return Card(
      color: AppColors.surface,
      child: items.isEmpty
          ? const Center(
              child: Text('완성품 없음', style: TextStyle(color: Colors.grey)),
            )
          : DropdownButton<CraftedItem>(
              isExpanded: true,
              hint: const Center(child: Text('진열할 아이템...')),
              items: items.map((item) {
                return DropdownMenuItem(
                  value: item,
                  child: Text('${item.name} (${item.sellPrice}G)'),
                );
              }).toList(),
              onChanged: (item) {
                if (item != null) {
                  shop.displayItem(item);
                }
              },
            ),
    );
  }

  Widget _buildUpgradeTab() {
    return Consumer4<
      StationManager,
      MaterialInventory,
      EconomyManager,
      CraftingManager
    >(
      builder: (context, stations, inventory, economy, crafting, child) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Exploration Upgrades Section
            Text('탐험 업그레이드', style: AppTextStyles.header2),
            const SizedBox(height: 12),
            Consumer<UpgradeManager>(
              builder: (context, upgrades, _) {
                return Column(
                  children: UpgradeType.values.map((type) {
                    final level = upgrades.getLevel(type);
                    final cost = upgrades.getUpgradeCost(type);
                    final canAfford = upgrades.canAfford(type);

                    String name;
                    String desc;
                    IconData icon;

                    switch (type) {
                      case UpgradeType.explorationSpeed:
                        name = '탐험 속도';
                        desc = '던전 탐험 시간이 10% 감소합니다.';
                        icon = Icons.speed;
                        break;
                      case UpgradeType.lootLuck:
                        name = '행운';
                        desc = '희귀 재료 발견 확률이 10% 증가합니다.';
                        icon = Icons.auto_awesome;
                        break;
                    }

                    return Card(
                      color: AppColors.panel,
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: Icon(icon, color: Colors.amber),
                        title: Text('$name Lv.$level'),
                        subtitle: Text(
                          '$desc\n비용: $cost 골드',
                          style: AppTextStyles.caption,
                        ),
                        isThreeLine: true,
                        trailing: ElevatedButton(
                          onPressed: canAfford
                              ? () {
                                  if (upgrades.buyUpgrade(type)) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('$name 업그레이드 완료!'),
                                      ),
                                    );
                                  }
                                }
                              : null,
                          child: const Text('업그레이드'),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
            const SizedBox(height: 24),

            // Station Upgrades Section
            Text('제작소 업그레이드', style: AppTextStyles.header2),
            const SizedBox(height: 12),
            ...CraftingStation.values.map((station) {
              final data = stations.getStation(station);
              final canUpgrade = stations.canUpgrade(
                station,
                economy,
                inventory.hasMaterials,
              );

              return Card(
                color: AppColors.panel,
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Icon(
                    _getStationIcon(station),
                    color: AppColors.primary,
                  ),
                  title: Text('${data.getName()} Lv.${data.level}'),
                  subtitle: Text(
                    '속도: +${(data.speedMultiplier * 100 - 100).toInt()}% | 품질: +${(data.qualityBonus * 100).toInt()}%\n'
                    '비용: ${data.getUpgradeCostGold()} 골드',
                    style: AppTextStyles.caption,
                  ),
                  isThreeLine: true,
                  trailing: ElevatedButton(
                    onPressed: canUpgrade
                        ? () {
                            if (stations.upgradeStation(
                              station,
                              economy,
                              inventory.consumeMaterials,
                            )) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('${data.getName()} 업그레이드 완료!'),
                                ),
                              );
                            }
                          }
                        : null,
                    child: const Text('업그레이드'),
                  ),
                ),
              );
            }),

            const SizedBox(height: 24),

            // Recipe Unlocks Section
            Text('레시피 해금', style: AppTextStyles.header2),
            const SizedBox(height: 12),
            ...crafting
                .getAvailableUnlocks(economy.gold ~/ 100, economy.gold)
                .map((recipe) {
                  final requirement = RecipeUnlocks.getRequirement(recipe.id);
                  if (requirement == null) return const SizedBox.shrink();

                  return Card(
                    color: AppColors.panel,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: _getTierColor(recipe.tier),
                        child: Text(
                          _getTierShort(recipe.tier),
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                      title: Text(recipe.name),
                      subtitle: Text(
                        '${recipe.description}\n비용: ${requirement.goldCost} 골드',
                        style: AppTextStyles.caption,
                      ),
                      isThreeLine: true,
                      trailing: ElevatedButton(
                        onPressed: () {
                          if (crafting.unlockRecipeWithGold(
                            recipe.id,
                            economy.gold ~/ 100,
                            economy.gold,
                            (amount) => economy.spendGold(amount),
                          )) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('${recipe.name} 레시피 해금!')),
                            );
                          }
                        },
                        child: const Text('해금'),
                      ),
                    ),
                  );
                }),
          ],
        );
      },
    );
  }

  Color _getMaterialColor(MaterialType type) {
    switch (type) {
      case MaterialType.ironOre:
        return Colors.grey;
      case MaterialType.wood:
        return Colors.brown;
      case MaterialType.leather:
        return Colors.orange;
      case MaterialType.magicStone:
        return Colors.purple;
      case MaterialType.rareGem:
        return Colors.cyan;
    }
  }

  IconData _getMaterialIcon(MaterialType type) {
    switch (type) {
      case MaterialType.ironOre:
        return Icons.landscape;
      case MaterialType.wood:
        return Icons.forest;
      case MaterialType.leather:
        return Icons.checkroom;
      case MaterialType.magicStone:
        return Icons.auto_fix_high;
      case MaterialType.rareGem:
        return Icons.diamond;
    }
  }

  IconData _getStationIcon(CraftingStation station) {
    switch (station) {
      case CraftingStation.workbench:
        return Icons.construction;
      case CraftingStation.furnace:
        return Icons.local_fire_department;
      case CraftingStation.anvil:
        return Icons.gavel;
      case CraftingStation.alchemyTable:
        return Icons.science;
      case CraftingStation.enchanting:
        return Icons.auto_awesome;
    }
  }

  String _getStationName(CraftingStation station) {
    switch (station) {
      case CraftingStation.workbench:
        return '작업대';
      case CraftingStation.furnace:
        return '용광로';
      case CraftingStation.anvil:
        return '대장간';
      case CraftingStation.alchemyTable:
        return '연금술대';
      case CraftingStation.enchanting:
        return '마법부여대';
    }
  }

  Color _getTierColor(RecipeTier tier) {
    switch (tier) {
      case RecipeTier.basic:
        return Colors.grey;
      case RecipeTier.intermediate:
        return Colors.green;
      case RecipeTier.advanced:
        return Colors.blue;
      case RecipeTier.master:
        return Colors.purple;
      case RecipeTier.legendary:
        return Colors.orange;
    }
  }

  String _getTierShort(RecipeTier tier) {
    switch (tier) {
      case RecipeTier.basic:
        return '기본';
      case RecipeTier.intermediate:
        return '중급';
      case RecipeTier.advanced:
        return '고급';
      case RecipeTier.master:
        return '마스터';
      case RecipeTier.legendary:
        return '전설';
    }
  }

  String _getQualityName(Quality quality) {
    switch (quality) {
      case Quality.normal:
        return '일반';
      case Quality.good:
        return '양호';
      case Quality.excellent:
        return '우수';
      case Quality.masterpiece:
        return '걸작';
    }
  }

  Color _getQualityColor(Quality quality) {
    switch (quality) {
      case Quality.normal:
        return Colors.grey;
      case Quality.good:
        return Colors.green;
      case Quality.excellent:
        return Colors.blue;
      case Quality.masterpiece:
        return Colors.purple;
    }
  }

  Widget _buildDungeonTab() {
    return Consumer<DungeonManager>(
      builder: (context, dungeon, child) {
        final session = dungeon.activeSession;

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Active session
            if (session != null) ...[
              Card(
                color: AppColors.panel,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Text(
                        '${dungeon.getDungeonName(session.depth)} 탐험 중',
                        style: AppTextStyles.header2,
                      ),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(value: session.progress),
                      const SizedBox(height: 8),
                      Text(
                        '남은 시간: ${session.remainingTime.inSeconds}초',
                        style: AppTextStyles.body,
                      ),
                      const SizedBox(height: 12),
                      if (session.isComplete)
                        ElevatedButton(
                          onPressed: () {
                            final rewards = dungeon.completeExploration();
                            if (rewards.isNotEmpty && mounted) {
                              final rewardText = rewards.entries
                                  .map(
                                    (e) =>
                                        '${MaterialData.getByType(e.key).name} ${e.value}개',
                                  )
                                  .join(', ');
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('획득: $rewardText')),
                              );
                            }
                          },
                          child: const Text('보상 수령'),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Dungeon options
            Text('던전 선택', style: AppTextStyles.header2),
            const SizedBox(height: 12),
            ...[1, 2, 3].map((depth) {
              final unlocked = dungeon.isDepthUnlocked(depth);
              final canExplore = dungeon.canExplore() && unlocked;

              return Card(
                color: AppColors.panel,
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Icon(
                    Icons.explore,
                    color: unlocked ? AppColors.primary : Colors.grey,
                  ),
                  title: Text(dungeon.getDungeonName(depth)),
                  subtitle: Text(
                    dungeon.getDungeonDescription(depth),
                    style: AppTextStyles.caption,
                  ),
                  isThreeLine: true,
                  trailing: ElevatedButton(
                    onPressed: canExplore
                        ? () {
                            dungeon.startExploration(depth);
                          }
                        : null,
                    child: Text(unlocked ? '탐험' : '잠김'),
                  ),
                ),
              );
            }),
          ],
        );
      },
    );
  }

  Widget _buildAchievementsTab() {
    return Consumer2<AchievementManager, EconomyManager>(
      builder: (context, achievements, economy, child) {
        final unclaimed = achievements.unclaimedAchievements;

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Summary
            Card(
              color: AppColors.panel,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('업적 진행도', style: AppTextStyles.header2),
                    const SizedBox(height: 12),
                    Text(
                      '${achievements.completedAchievements} / ${achievements.totalAchievements} 달성',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (unclaimed.isNotEmpty)
                      Text(
                        '수령 대기중: ${unclaimed.length}개',
                        style: TextStyle(color: Colors.orange),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Achievements list
            Text('업적 목록', style: AppTextStyles.header2),
            const SizedBox(height: 12),
            ...achievements.allProgress.map((progress) {
              final canClaim = progress.canClaim;
              final claimed = progress.claimed;

              return Card(
                color: claimed ? AppColors.background : AppColors.panel,
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Icon(
                    claimed ? Icons.check_circle : Icons.emoji_events,
                    color: claimed
                        ? Colors.green
                        : (canClaim ? Colors.orange : Colors.grey),
                  ),
                  title: Text(progress.achievement.name),
                  subtitle: Text(
                    '${progress.achievement.description}\n'
                    '진행: ${progress.currentValue} / ${progress.achievement.targetValue}\n'
                    '보상: ${progress.achievement.reward.gold} 골드, ${progress.achievement.reward.gems} 보석',
                    style: AppTextStyles.caption,
                  ),
                  isThreeLine: true,
                  trailing: canClaim
                      ? ElevatedButton(
                          onPressed: () {
                            final reward = achievements.claimAchievement(
                              progress.achievement.id,
                            );
                            if (reward != null) {
                              economy.addGold(reward.gold);
                              economy.addGems(reward.gems);
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      '보상 획득: ${reward.gold} 골드, ${reward.gems} 보석',
                                    ),
                                  ),
                                );
                              }
                            }
                          },
                          child: const Text('수령'),
                        )
                      : (claimed
                            ? const Icon(Icons.check, color: Colors.green)
                            : null),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}
